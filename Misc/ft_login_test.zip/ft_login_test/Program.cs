﻿using System;
using System.Runtime.InteropServices;

class Program
{
    [DllImport("ft_session_token.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern IntPtr get_session_token(
        IntPtr user,
        IntPtr password,
        IntPtr totp_key,
        IntPtr api_key,
        IntPtr api_secret
    );

    static void Main()
    {
        string user = "Your Username";
        string password = "Your Password#";
        string totpKey = "Your TOTP Key";
        string apiKey = "Your API Key";
        string apiSecret = "Your API Secret";

        IntPtr userPtr = Marshal.StringToHGlobalAnsi(user);
        IntPtr passwordPtr = Marshal.StringToHGlobalAnsi(password);
        IntPtr totpKeyPtr = Marshal.StringToHGlobalAnsi(totpKey);
        IntPtr apiKeyPtr = Marshal.StringToHGlobalAnsi(apiKey);
        IntPtr apiSecretPtr = Marshal.StringToHGlobalAnsi(apiSecret);

        IntPtr result = get_session_token(userPtr, passwordPtr, totpKeyPtr, apiKeyPtr, apiSecretPtr);

        Marshal.FreeHGlobal(userPtr);
        Marshal.FreeHGlobal(passwordPtr);
        Marshal.FreeHGlobal(totpKeyPtr);
        Marshal.FreeHGlobal(apiKeyPtr);
        Marshal.FreeHGlobal(apiSecretPtr);

        string token = Marshal.PtrToStringAnsi(result);
        Console.WriteLine("Received token: " + token);
    }
}
